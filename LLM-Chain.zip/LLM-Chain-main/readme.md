# LLM-Chain
LLM-Chain is a fuzz testing tool that leverages LLMs to generate test cases prior to the fuzz testing process.

The three numbers in the metrics column represent TP (True Positives), FP (False Positives), and the total number of vulnerabilities, respectively. The method proposed in paper shows a 1.5% improvement in average instruction coverage.The F1-score also increased by 0.072.
![image](https://github.com/user-attachments/assets/65bbaed3-9bdb-461e-ae76-a6b8db566967)
